export const upperCase = (string) => {
  return string.toUpperCase();
};
