import homeIcon from "./icons/_home-icon.png";
import notificationIcon from "./icons/_notification-icon.png";
import profileIcon from "./icons/_profile-icon.png";
import mannageAuctionIcon from "./icons/_mannage-auction-icon.png";
import mannageBuyerIcon from "./icons/_mannage-buyer-icon.png";
import dashboardIcon from "./icons/_dashboard-icon.png";
import settingsIcon from "./icons/_settings-icon.png";
import dieselIcon from "./icons/_diesel-icon.png";
import filterIcon from "./icons/_filter-icon.png";
import searchIcon from "./icons/_search-icon.png";
import mannageAdminIcon from "./icons/_mannageAdmin.png";

export {
  homeIcon,
  notificationIcon,
  profileIcon,
  mannageAuctionIcon,
  mannageBuyerIcon,
  dashboardIcon,
  settingsIcon,
  dieselIcon,
  filterIcon,
  searchIcon,
  mannageAdminIcon,
};
