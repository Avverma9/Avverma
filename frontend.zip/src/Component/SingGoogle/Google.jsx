import React from "react";
import "./Google.css";

import { getAuth, GoogleAuthProvider, signInWithPopup } from "firebase/auth";
import { useNavigate } from "react-router-dom";

const Google = () => {
  const navigate = useNavigate();

  const auth = getAuth();
  const provider = new GoogleAuthProvider();

  const handleGoogleLogin = async (e) => {
    e.preventDefault();

    try {
      const result = await signInWithPopup(auth, provider);
      if (result.user) {
        const user = result.user;
        const userEmail = user.email.toLowerCase();

        localStorage.setItem("isSignedIn", "true");
        localStorage.setItem("loggedUser", JSON.stringify(user));

        // Send user email to your backend
        fetch("https://hotel-backend-tge7.onrender.com/signin", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ userEmail }),
        });

        setTimeout(() => {
          navigate("/profile");
        }, 500);
      }
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div className="google-container" onClick={handleGoogleLogin}>
      <p className="google-text">Continue With</p>
      <img
        src="https://freepngimg.com/thumb/google/153884-logo-google-png-download-free.png"
        alt="Google Logo"
        className="google-logo"
      />
    </div>
  );
};

export default Google;
