import React from "react";
import "./Debitemd.css";

export const Debitemd = () => {
  return (
    <div className="debit_emd_container">
      <h1>Emd Account</h1>
      <input type="text" value="abcd" />
      <h1>Debit Notes</h1>
      <textarea cols="30" rows="5">
        abcd
      </textarea>
    </div>
  );
};
