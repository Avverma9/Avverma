export const NoShowBooking = () => {
  return (
    <>
      <div className="_title">
        <h1>NoShow Booking</h1>
      </div>
      <div className="sub_Title">No Booking done yet</div>
    </>
  );
};
