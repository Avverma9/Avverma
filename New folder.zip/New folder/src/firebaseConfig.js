// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDf6tlkMLI-BKpBpTn4pzBmTfNx6LYXP7c",
  authDomain: "authenticate-b1d20.firebaseapp.com",
  projectId: "authenticate-b1d20",
  storageBucket: "authenticate-b1d20.appspot.com",
  messagingSenderId: "337824475651",
  appId: "1:337824475651:web:583ca0ef97e52bf3e27c36",
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
