export const FailedBooking = () => {
  return (
    <>
      <div className="_title">
        <h1>Failed Booking</h1>
      </div>
      <div className="sub_Title">Booking failed. Please try again later</div>
    </>
  );
}
