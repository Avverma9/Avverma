import React from 'react'
import "./Assignbuyer.css"

export const Assignbuyer = () => {
  return (
    <div>Assignbuyer</div>
  )
}
