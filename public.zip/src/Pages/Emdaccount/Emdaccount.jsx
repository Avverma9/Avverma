import React from 'react'
import "./Emdaccount.css"


export const Emdaccount = () => {


  return (
      <div className="emd_account_container">
          <h1>Emd Account</h1>
          <input type="" value="" />
          <h1>Credit Notes</h1>
          <textarea  cols="30" rows="5">abcd</textarea>
          <div className='button-btn'>
            <button className='save-button'>Save</button>
          </div>
    </div>
    
  )
}
