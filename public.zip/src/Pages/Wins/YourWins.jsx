import React from "react";

import "./YourWins.css";
import { Bidcard } from "../../Component/Bidcard/Bidcard";
import { FiSearch } from 'react-icons/fi';
import { BiSortAlt2 } from 'react-icons/bi';
import { BsFilter } from 'react-icons/bs';

export const YourWins = () => {

  return (

    <div className="your_wins_wrapper">
      <div>
        <div className='live-header'>
          <h1> <span>311</span>Auctions</h1>
          <div className='live-icons'>
            <FiSearch />
            <BsFilter />
            <BiSortAlt2 />
          </div>
        </div>
        <Bidcard />
      </div>
      <div>
        <div className='live-header'>
          <h1> <span>311</span>Auctions</h1>
          <div className='live-icons'>
            <FiSearch />
            <BsFilter />
            <BiSortAlt2 />
          </div>
        </div>
        <Bidcard />
      </div>
      <div>
        <div className='live-header'>
          <h1> <span>311</span>Auctions</h1>
          <div className='live-icons'>
            <FiSearch />
            <BsFilter />
            <BiSortAlt2 />
          </div>
        </div>
        <Bidcard />
      </div>
      <div>
        <div className='live-header'>
          <h1> <span>311</span>Auctions</h1>
          <div className='live-icons'>
            <FiSearch />
            <BsFilter />
            <BiSortAlt2 />
          </div>
        </div>
        <Bidcard />
      </div>
      <div>
        <div className='live-header'>
          <h1> <span>311</span>Auctions</h1>
          <div className='live-icons'>
            <FiSearch />
            <BsFilter />
            <BiSortAlt2 />
          </div>
        </div>
        <Bidcard />
      </div>
      <div>
        <div className='live-header'>
          <h1> <span>311</span>Auctions</h1>
          <div className='live-icons'>
            <FiSearch />
            <BsFilter />
            <BiSortAlt2 />
          </div>
        </div>
        <Bidcard />
      </div>
      <div>
        <div className='live-header'>
          <h1> <span>311</span>Auctions</h1>
          <div className='live-icons'>
            <FiSearch />
            <BsFilter />
            <BiSortAlt2 />
          </div>
        </div>
        <Bidcard />
      </div>
      <div>
        <div className='live-header'>
          <h1> <span>311</span>Auctions</h1>
          <div className='live-icons'>
            <FiSearch />
            <BsFilter />
            <BiSortAlt2 />
          </div>
        </div>
        <Bidcard />
      </div>
      <div>
        <div className='live-header'>
          <h1> <span>311</span>Auctions</h1>
          <div className='live-icons'>
            <FiSearch />
            <BsFilter />
            <BiSortAlt2 />
          </div>
        </div>
        <Bidcard />
      </div>
      <div>
        <div className='live-header'>
          <h1> <span>311</span>Auctions</h1>
          <div className='live-icons'>
            <FiSearch />
            <BsFilter />
            <BiSortAlt2 />
          </div>
        </div>
        <Bidcard />
      </div>
      <div>
        <div className='live-header'>
          <h1> <span>311</span>Auctions</h1>
          <div className='live-icons'>
            <FiSearch />
            <BsFilter />
            <BiSortAlt2 />
          </div>
        </div>
        <Bidcard />
      </div>
    </div>

  );
};
export default YourWins
