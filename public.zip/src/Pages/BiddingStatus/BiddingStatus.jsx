import React from "react";
import "./BiddingStatus.css";
import { Bidcard } from "../../Component/Bidcard/Bidcard";

export const BiddingStatus = () => {
  return (
    <div className="bidding_status_wrapper">
      <Bidcard />
    </div>
  );
};
